#include "conv1d_layer.h"
#include "dense_layer.h"
#include "model_params.h"
#include <stdint.h>

#define INPUT_SIZE 17
#define CONV1_OUT 20
#define CONV2_OUT 20
#define FC1_OUT 16
#define FC2_OUT 8

int32_t conv1_out[CONV1_OUT * INPUT_SIZE];
int32_t conv2_out[CONV2_OUT * INPUT_SIZE];
int32_t gap_out[CONV2_OUT];
int32_t fc1_out[FC1_OUT];
int32_t fc2_out[FC2_OUT];

uint8_t run_inference(int8_t *input)
{

    /* ---------- Conv Layer 1 ---------- */

    conv1d_forward(
        input,
        CONV1_W,
        CONV1_B,
        conv1_out,
        INPUT_SIZE,
        3,
        1,
        CONV1_OUT
    );

    /* ---------- Conv Layer 2 ---------- */

    conv1d_forward(
        (int8_t*)conv1_out,
        CONV2_W,
        CONV2_B,
        conv2_out,
        INPUT_SIZE,
        3,
        CONV1_OUT,
        CONV2_OUT
    );

    /* ---------- Global Average Pool ---------- */

    for(int c=0; c<CONV2_OUT; c++)
    {
        int32_t sum = 0;

        for(int i=0; i<INPUT_SIZE; i++)
        {
            sum += conv2_out[c*INPUT_SIZE + i];
        }

        gap_out[c] = sum / INPUT_SIZE;
    }

    /* ---------- Dense Layer 1 ---------- */

    dense_forward(
        gap_out,
        FC1_W,
        FC1_B,
        fc1_out,
        CONV2_OUT,
        FC1_OUT
    );

    /* ---------- Dense Layer 2 ---------- */

    dense_forward(
        fc1_out,
        FC2_W,
        FC2_B,
        fc2_out,
        FC1_OUT,
        FC2_OUT
    );

    /* ---------- Argmax ---------- */

    int max_index = 0;
    int32_t max_val = fc2_out[0];

    for(int i=1;i<FC2_OUT;i++)
    {
        if(fc2_out[i] > max_val)
        {
            max_val = fc2_out[i];
            max_index = i;
        }
    }

    return max_index;
}
