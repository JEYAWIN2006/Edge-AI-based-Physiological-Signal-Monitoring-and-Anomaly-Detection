#include "conv1d_layer.h"

void conv1d_forward(
    const int8_t *input,
    const int8_t *weights,
    const int32_t *bias,
    int8_t *output,
    int input_length,
    int kernel_size,
    int input_channels,
    int output_channels
)
{
    int output_length = input_length - kernel_size + 1;

    for(int oc = 0; oc < output_channels; oc++)
    {
        for(int pos = 0; pos < output_length; pos++)
        {
            int32_t sum = bias[oc];

            for(int ic = 0; ic < input_channels; ic++)
            {
                for(int k = 0; k < kernel_size; k++)
                {
                    int input_index =
                        (pos + k) * input_channels + ic;

                    int weight_index =
                        oc * (kernel_size * input_channels)
                        + ic * kernel_size
                        + k;

                    sum += input[input_index] *
                           weights[weight_index];
                }
            }

            /* ReLU activation */
            if(sum < 0) sum = 0;

            /* INT8 clipping */
            if(sum > 127) sum = 127;

            output[pos * output_channels + oc] =
                (int8_t)sum;
        }
    }
}
