#include <stdio.h>
#include <stdint.h>
#include "model_params.h"

extern uint8_t run_inference(int8_t *input);

#define NUM_SAMPLES 20

/* Condition labels */
const char *condition_names[8] =
{
		"NORMAL",
		"ARRHYTHMIA",
		"HYPERTENSION",
		"HYPOTENSION",
		"STRESS",
		"FEVER",
		"MOTION_ARTIFACT",
		"HYPOXIA"
};

/* Test physiological samples */
int8_t test_data[NUM_SAMPLES][FEAT_LEN] =
{
/* NORMAL */
{72,120,80,37,0,85,80,32,0,0,0,1,0,0,0,0,1},
{70,118,78,37,0,83,79,31,0,1,0,0,0,0,0,1,0},

/* ARRHYTHMIA (irregular HR, abnormal ECG) */
{95,125,82,37,0,120,85,33,0,0,1,0,1,0,0,0,1},
{110,130,85,37,0,130,90,34,0,1,1,0,0,1,0,0,0},

/* HYPERTENSION */
{85,150,95,37,0,90,82,36,0,0,0,1,0,1,0,0,1},
{88,155,98,37,0,92,84,35,0,0,1,0,0,0,1,0,0},

/* HYPOTENSION */
{60,90,60,36,0,75,70,30,0,0,0,0,1,0,0,1,0},
{58,85,58,36,0,73,68,29,0,1,0,0,0,0,1,0,0},

/* STRESS */
{100,140,90,37,1,110,95,40,1,1,0,1,0,0,1,0,0},
{105,145,92,37,1,112,96,42,0,1,1,0,0,0,1,0,0},

/* FEVER */
{90,130,85,39,0,95,90,35,0,0,0,0,0,1,0,1,0},
{92,132,87,39,0,97,91,36,0,0,1,0,1,0,0,1,0},

/* MOTION_ARTIFACT (large IMU values) */
{78,118,80,37,1,85,80,33,3,2,2,0,0,0,0,0,1},
{80,120,82,37,1,86,81,34,2,3,2,0,0,1,0,0,0},

/* HYPOXIA (low PPG signal, high HR) */
{110,130,88,37,0,120,50,28,0,0,0,1,0,0,1,0,0},
{112,132,90,37,0,125,48,27,0,0,1,0,0,1,0,0,0}
};

int main()
{
    printf("\nPhysiological Signal Monitoring\n\n");

    while(1)
    {
        for(int i = 0; i < NUM_SAMPLES; i++)
        {
            int8_t *sample = test_data[i];

            int HR      = sample[0];
            int BP_sys  = sample[1];
            int BP_dia  = sample[2];
            int Temp    = sample[3];
            int Motion  = sample[4];

            int ECG     = sample[5];
            int PPG     = sample[6];
            int GSR     = sample[7];

            int IMU_AX  = sample[8];
            int IMU_AY  = sample[9];
            int IMU_AZ  = sample[10];

            uint8_t prediction = run_inference(sample);

            /* clear terminal screen */
          //  printf("\033[2J\033[H");

            printf("======================================\n");
            printf("        EDGE AI HEALTH MONITOR\n");
            printf("======================================\n");

            printf("Sample     : %d\n\n", i+1);

            printf("ECG SENSOR : %d\n", ECG);
            printf("PPG SENSOR : %d\n", PPG);
            printf("GSR SENSOR : %d\n", GSR);

            printf("\nHR        : %d BPM\n", HR);
            printf("BP        : %d / %d mmHg\n", BP_sys, BP_dia);
            printf("TEMP      : %d C\n", Temp);
            printf("MOTION    : %d\n", Motion);

            printf("\nIMU ACC   : %d %d %d\n", IMU_AX, IMU_AY, IMU_AZ);

            /* Debug prediction ID */
            printf("\nPrediction ID : %d\n", prediction);

            if(prediction >= 0 && prediction < 8)
                printf("AI STATUS     : %s\n", condition_names[prediction]);
            else
                printf("AI STATUS     : UNKNOWN\n");

            printf("======================================\n");

            /* delay (~1 sec) */
            for(volatile int d=0; d<12000000; d++);
        }
    }

    return 0;
}
