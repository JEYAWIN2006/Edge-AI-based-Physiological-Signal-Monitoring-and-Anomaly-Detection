#pragma once
#include <stdint.h>

#define FEAT_LEN 17
#define C_OUT 20
#define FC1_OUT 16
#define FC2_OUT 8

extern const int8_t  CONV1_W[20*1*3*1];
extern const int32_t CONV1_B[20];
extern const float   CONV1_W_SCALE[20];

extern const int8_t  CONV2_W[20*1*3*20];
extern const int32_t CONV2_B[20];
extern const float   CONV2_W_SCALE[20];

extern const int8_t  FC1_W[16*20];
extern const int32_t FC1_B[16];
extern const float   FC1_W_SCALE[16];

extern const int8_t  FC2_W[8*16];
extern const int32_t FC2_B[8];
extern const float   FC2_W_SCALE[8];
