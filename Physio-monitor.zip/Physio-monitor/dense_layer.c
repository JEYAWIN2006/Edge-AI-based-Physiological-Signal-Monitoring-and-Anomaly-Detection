#include "dense_layer.h"

void dense_forward(
    const int8_t *input,
    const int8_t *weights,
    const int32_t *bias,
    int8_t *output,
    int input_size,
    int output_size
)
{
    for(int o = 0; o < output_size; o++)
    {
        int32_t sum = bias[o];

        for(int i = 0; i < input_size; i++)
        {
            int w_index = o * input_size + i;

            sum += input[i] * weights[w_index];
        }

        if(sum < 0) sum = 0;
        if(sum > 127) sum = 127;

        output[o] = (int8_t)sum;
    }
}
