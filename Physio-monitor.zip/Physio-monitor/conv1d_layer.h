#ifndef CONV1D_LAYER_H
#define CONV1D_LAYER_H

#include <stdint.h>

void conv1d_forward(
    const int8_t *input,
    const int8_t *weights,
    const int32_t *bias,
    int8_t *output,
    int input_length,
    int kernel_size,
    int input_channels,
    int output_channels
);

#endif
