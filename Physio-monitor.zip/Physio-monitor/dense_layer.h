#ifndef DENSE_LAYER_H
#define DENSE_LAYER_H

#include <stdint.h>

void dense_forward(
    const int8_t *input,
    const int8_t *weights,
    const int32_t *bias,
    int8_t *output,
    int input_size,
    int output_size
);

#endif
